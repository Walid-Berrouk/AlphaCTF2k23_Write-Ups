<?php 
    $flag="AlphaCTF{heloooooo}"; 
    if (isset($_GET['src'])) {
        if (strpos($_GET['src'], "?") !== FALSE) {
            echo 'hmmm';
            die();
        }
    }
?>  

my name is:
<?php
include "data://text/plain;base64,".base64_encode($_GET['src']);
?>